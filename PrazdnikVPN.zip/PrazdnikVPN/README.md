# PRAZDNIK VPN — Android

Красивое Android-приложение VPN с выбором локаций.

## Что уже есть

- Современный тёмный UI на Jetpack Compose + Material 3
- Выбор локации: 🇳🇱 Нидерланды, 🇩🇪 Германия, 🇬🇧 Великобритания, 🇫🇷 Франция, 🇺🇸 США
- Большая анимированная кнопка «Подключить / Отключить»
- Техподдержка → сразу открывает письмо на `prazdnikvpnsupport@gmail.com`
- Конфиг OpenVPN для **Нидерландов** (лежит в `app/src/main/assets/netherlands.ovpn`)
- Базовый `VpnService` (каркас)

## Важно про реальную работу VPN

Текущий `PrazdnikVpnService` создаёт TUN-интерфейс и уведомление, **но не выполняет настоящий OpenVPN-протокол**.

Чтобы VPN **реально** менял IP и работал с Roblox / YouTube / Brawl Stars, нужно подключить одну из библиотек:

### Рекомендуемый способ (самый простой)

1. Установи **OpenVPN Connect** из Google Play  
   https://play.google.com/store/apps/details?id=net.openvpn.openvpn

2. Скопируй файл `app/src/main/assets/netherlands.ovpn` на телефон.

3. Открой OpenVPN Connect → Import Profile → выбери файл.

4. Подключайся.

Это самый быстрый способ проверить, работает ли сервер вообще (лёгкий/средний/сложный тесты).

### Полноценный собственный клиент (для продакшена)

Нужна библиотека **ics-openvpn** (GPL):

- https://github.com/schwabe/ics-openvpn
- Или готовые примеры:
  - https://github.com/ashraf789/Cake-VPN
  - https://github.com/tanujsinghkushwah/ether-vpn
  - https://github.com/nnjun/SimpleOpenVpn-Android

Шаги:
1. Добавь модуль `openvpn` как submodule или dependency.
2. В `PrazdnikVpnService` вместо заглушки вызови API библиотеки и передай содержимое `.ovpn`.
3. Приложение должно быть open-source (требование GPL).

## Как скачать ZIP и собрать APK через GitHub (без компьютера)

### Шаг 1. Создай репозиторий на GitHub
1. Зайди на https://github.com/new
2. Название: `PrazdnikVPN`
3. Сделай **Public**
4. Нажми **Create repository**

### Шаг 2. Загрузи код
**Вариант А (самый простой):**
1. На странице нового репозитория нажми **uploading an existing file**
2. Перетащи весь ZIP или распакованную папку `PrazdnikVPN`
3. Commit changes

**Вариант Б (через GitHub Desktop / git):**
```bash
git clone https://github.com/ТВОЙ_НИК/PrazdnikVPN.git
# скопируй файлы из ZIP внутрь
git add .
git commit -m "Initial commit"
git push
```

### Шаг 3. Собери APK через GitHub Actions
1. В репозитории перейди во вкладку **Actions**
2. Слева выбери workflow **Build APK**
3. Нажми **Run workflow** → **Run workflow**
4. Подожди 2–4 минуты
5. Когда сборка закончится — открой её и скачай артефакт **PrazdnikVPN-debug**
6. Внутри будет файл `.apk` — установи на телефон

> Если workflow упадёт (часто из-за отсутствия полного Gradle Wrapper), самый надёжный способ — открыть проект один раз в Android Studio (он сам докачает всё).

### Альтернатива — Android Studio (рекомендуется)
1. Скачай и установи Android Studio: https://developer.android.com/studio
2. File → Open → выбери папку `PrazdnikVPN`
3. Дождись синхронизации Gradle (первый раз может занять 5–10 минут)
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK будет здесь: `app/build/outputs/apk/debug/app-debug.apk`

## Добавление других стран

Когда появятся конфиги:

1. Положи файлы в `app/src/main/assets/` (например `germany.ovpn`).
2. В `MainActivity.kt` в списке `locations` укажи `configAsset = "germany.ovpn"`.

## Тесты, которые ты планируешь

- **Лёгкий**: картинки в Roblox
- **Средний**: YouTube видео
- **Сложный**: Brawl Stars

После того как подключишь настоящий OpenVPN-движок или просто импортируешь `.ovpn` в OpenVPN Connect — пиши результаты, подправим (DNS, MTU, маршруты и т.д.).

## Контакты в приложении

Техподдержка: **prazdnikvpnsupport@gmail.com**
