package com.prazdnik.vpn

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

data class VpnLocation(
    val id: String,
    val name: String,
    val flag: String,
    val countryCode: String,
    val configAsset: String? // null = not available yet
)

val locations = listOf(
    VpnLocation("nl", "Нидерланды", "🇳🇱", "NL", "netherlands.ovpn"),
    VpnLocation("de", "Германия", "🇩🇪", "DE", null),
    VpnLocation("gb", "Великобритания", "🇬🇧", "GB", null),
    VpnLocation("fr", "Франция", "🇫🇷", "FR", null),
    VpnLocation("us", "США", "🇺🇸", "US", null)
)

class MainActivity : ComponentActivity() {

    private var selectedLocation by mutableStateOf(locations[0])
    private var isConnected by mutableStateOf(false)
    private var isConnecting by mutableStateOf(false)

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnService()
        } else {
            Toast.makeText(this, "Разрешение VPN отклонено", Toast.LENGTH_SHORT).show()
            isConnecting = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PrazdnikTheme {
                MainScreen(
                    selectedLocation = selectedLocation,
                    isConnected = isConnected,
                    isConnecting = isConnecting,
                    onLocationSelected = { loc ->
                        if (!isConnected && !isConnecting) {
                            selectedLocation = loc
                        }
                    },
                    onConnectClick = { toggleVpn() },
                    onSupportClick = { openSupport() }
                )
            }
        }
    }

    private fun toggleVpn() {
        if (isConnected) {
            stopVpnService()
        } else {
            if (selectedLocation.configAsset == null) {
                Toast.makeText(
                    this,
                    "Конфиг для ${selectedLocation.name} пока недоступен.\nПока работает только Нидерланды.",
                    Toast.LENGTH_LONG
                ).show()
                return
            }
            isConnecting = true
            val intent = VpnService.prepare(this)
            if (intent != null) {
                vpnPermissionLauncher.launch(intent)
            } else {
                startVpnService()
            }
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, PrazdnikVpnService::class.java).apply {
            action = PrazdnikVpnService.ACTION_CONNECT
            putExtra(PrazdnikVpnService.EXTRA_CONFIG, selectedLocation.configAsset)
            putExtra(PrazdnikVpnService.EXTRA_LOCATION, selectedLocation.name)
        }
        ContextCompat.startForegroundService(this, intent)
        isConnected = true
        isConnecting = false
        Toast.makeText(this, "Подключение к ${selectedLocation.name}...", Toast.LENGTH_SHORT).show()
    }

    private fun stopVpnService() {
        val intent = Intent(this, PrazdnikVpnService::class.java).apply {
            action = PrazdnikVpnService.ACTION_DISCONNECT
        }
        startService(intent)
        isConnected = false
        isConnecting = false
        Toast.makeText(this, "VPN отключён", Toast.LENGTH_SHORT).show()
    }

    private fun openSupport() {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:prazdnikvpnsupport@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, "Поддержка PRAZDNIK VPN")
            putExtra(Intent.EXTRA_TEXT, "Здравствуйте!\n\nОпишите проблему:\n")
        }
        try {
            startActivity(Intent.createChooser(intent, "Написать в поддержку"))
        } catch (e: Exception) {
            Toast.makeText(this, "Нет приложения для почты", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun PrazdnikTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF7C4DFF),
            secondary = Color(0xFF00E5FF),
            background = Color(0xFF0D0D0D),
            surface = Color(0xFF1A1A1A),
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun MainScreen(
    selectedLocation: VpnLocation,
    isConnected: Boolean,
    isConnecting: Boolean,
    onLocationSelected: (VpnLocation) -> Unit,
    onConnectClick: () -> Unit,
    onSupportClick: () -> Unit
) {
    val buttonColor by animateColorAsState(
        targetValue = when {
            isConnecting -> Color(0xFFFFA726)
            isConnected -> Color(0xFF00E676)
            else -> Color(0xFF7C4DFF)
        },
        animationSpec = tween(400), label = "btnColor"
    )
    val scale by animateFloatAsState(
        targetValue = if (isConnected) 1.05f else 1f,
        animationSpec = tween(300), label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0D0D0D), Color(0xFF1A0A2E), Color(0xFF0D0D0D))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(32.dp))

            // Logo / Title
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = Color(0xFF7C4DFF),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "PRAZDNIK VPN",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = if (isConnected) "Защищено • ${selectedLocation.name}" else "Не подключено",
                fontSize = 14.sp,
                color = if (isConnected) Color(0xFF00E676) else Color(0xFFAAAAAA)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Big Connect Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(180.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(buttonColor.copy(alpha = 0.3f), Color.Transparent)
                        )
                    )
                    .border(4.dp, buttonColor, CircleShape)
                    .clickable(enabled = !isConnecting) { onConnectClick() }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = null,
                        tint = buttonColor,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = when {
                            isConnecting -> "ПОДКЛЮЧЕНИЕ..."
                            isConnected -> "ОТКЛЮЧИТЬ"
                            else -> "ПОДКЛЮЧИТЬ"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Location selector title
            Text(
                text = "Выберите локацию",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Locations list
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(locations) { location ->
                    LocationItem(
                        location = location,
                        isSelected = location.id == selectedLocation.id,
                        enabled = !isConnected && !isConnecting,
                        onClick = { onLocationSelected(location) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Support button
            OutlinedButton(
                onClick = onSupportClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFF7C4DFF), Color(0xFF00E5FF))
                    )
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Email,
                    contentDescription = null,
                    tint = Color(0xFF00E5FF)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Техподдержка",
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "prazdnikvpnsupport@gmail.com",
                fontSize = 12.sp,
                color = Color(0xFF888888),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun LocationItem(
    location: VpnLocation,
    isSelected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val bgColor = if (isSelected) Color(0xFF7C4DFF).copy(alpha = 0.25f) else Color(0xFF1A1A1A)
    val borderColor = if (isSelected) Color(0xFF7C4DFF) else Color(0xFF333333)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(bgColor)
            .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = location.flag, fontSize = 28.sp)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = location.name,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
            Text(
                text = if (location.configAsset != null) "Доступно" else "Скоро",
                color = if (location.configAsset != null) Color(0xFF00E676) else Color(0xFFFFA726),
                fontSize = 12.sp
            )
        }
        if (isSelected) {
            Icon(
                imageVector = Icons.Default.Speed,
                contentDescription = null,
                tint = Color(0xFF7C4DFF),
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
