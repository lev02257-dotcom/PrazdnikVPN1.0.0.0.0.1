PRAZDNIK VPN - OpenVPN configs

Логин/пароль для VPNBook (USA, UK, Germany):
  username: vpnbook
  password: 3ssumf2
  (пароль меняется — проверяй на https://www.vpnbook.com/freevpn/openvpn)

Netherlands (87.208.84.13) — публичный SoftEther-style, обычно без логина
France (Riseup) — обычно без логина или свои credentials

Файлы:
  usa.ovpn          - США (VPNBook)
  uk.ovpn           - Великобритания (VPNBook)
  germany.ovpn      - Германия (VPNBook)
  netherlands.ovpn  - Нидерланды
  france.ovpn       - Франция (Riseup)
  netherlands-softether-old.ovpn - старый SoftEther (тот что был изначально)

Как использовать:
1. Установи OpenVPN Connect
2. Импортируй .ovpn
3. Подключайся
