package com.prazdnik.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Базовый VpnService.
 *
 * ВАЖНО: Это каркас.
 * Чтобы VPN реально работал (менял IP, шифровал трафик через OpenVPN-сервер),
 * нужно подключить библиотеку ics-openvpn или openvpn3.
 *
 * Сейчас сервис создаёт TUN-интерфейс и показывает уведомление.
 * Трафик пока не маршрутизируется через реальный OpenVPN-туннель.
 *
 * Инструкция по подключению настоящей библиотеки — в README.
 */
class PrazdnikVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.prazdnik.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.prazdnik.vpn.DISCONNECT"
        const val EXTRA_CONFIG = "config_asset"
        const val EXTRA_LOCATION = "location_name"
        private const val TAG = "PrazdnikVPN"
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "prazdnik_vpn_channel"
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val isRunning = AtomicBoolean(false)
    private var locationName: String = "Нидерланды"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                locationName = intent.getStringExtra(EXTRA_LOCATION) ?: "Нидерланды"
                val configAsset = intent.getStringExtra(EXTRA_CONFIG)
                startForeground(NOTIFICATION_ID, createNotification("Подключение к $locationName..."))
                connect(configAsset)
            }
            ACTION_DISCONNECT -> {
                disconnect()
            }
        }
        return START_STICKY
    }

    private fun connect(configAsset: String?) {
        if (isRunning.get()) return

        try {
            // Читаем конфиг (на будущее — когда подключим OpenVPN-движок)
            if (configAsset != null) {
                val config = assets.open(configAsset).bufferedReader().use { it.readText() }
                Log.d(TAG, "Config loaded, length=${config.length}")
                // Здесь должен быть вызов OpenVPN-движка:
                // OpenVpnManager.connect(config)
            }

            // Создаём базовый TUN-интерфейс (заглушка)
            val builder = Builder()
                .setSession("PRAZDNIK VPN — $locationName")
                .addAddress("10.8.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
                .addDnsServer("1.1.1.1")
                .setMtu(1500)
                .setBlocking(true)

            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                Log.e(TAG, "Failed to establish VPN interface")
                stopSelf()
                return
            }

            isRunning.set(true)
            updateNotification("Подключено • $locationName")

            // Запускаем простой цикл чтения/записи (заглушка — в реальности это делает OpenVPN)
            Thread {
                try {
                    val input = FileInputStream(vpnInterface!!.fileDescriptor)
                    val output = FileOutputStream(vpnInterface!!.fileDescriptor)
                    val buffer = ByteBuffer.allocate(32767)

                    while (isRunning.get()) {
                        val length = input.read(buffer.array())
                        if (length > 0) {
                            // Здесь должен быть шифрованный обмен с сервером
                            // Пока просто «съедаем» пакеты (заглушка)
                            buffer.clear()
                        } else {
                            Thread.sleep(100)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "VPN loop error", e)
                }
            }.start()

            Log.i(TAG, "VPN started for $locationName")

        } catch (e: Exception) {
            Log.e(TAG, "Connect failed", e)
            disconnect()
        }
    }

    private fun disconnect() {
        isRunning.set(false)
        try {
            vpnInterface?.close()
        } catch (_: Exception) {}
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.i(TAG, "VPN stopped")
    }

    private fun createNotification(text: String): Notification {
        createNotificationChannel()

        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PRAZDNIK VPN")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, createNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PRAZDNIK VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Статус VPN-подключения"
            }
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }
}
